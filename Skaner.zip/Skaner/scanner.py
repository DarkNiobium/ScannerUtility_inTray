import threading
from pynput import keyboard as pyn_keyboard
import pystray
from PIL import Image, ImageDraw
import time
import csv
import os
import ctypes
from functools import partial

SAVE_FILE_TEMPLATE = "scanner_data_{}.csv"
CONFIG_FILE = "config.txt"
ACCOUNTS = ["Akbarjon", "Abubakr", "Abdulloh", "Guest"]

class ScannerApp:
    def __init__(self):
        self.account = self.load_last_account()
        self.buffer = ''
        self.count = 0
        self.last_scan = ''
        self.running = True
        self.paused = False
        self.icon = None
        self.last_key_time = 0
        self.max_delay = 0.05
        self.scanned_codes = set()
        self.load_data()

    def get_save_file(self):
        return SAVE_FILE_TEMPLATE.format(self.account)

    def load_last_account(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    account = f.read().strip()
                    if account in ACCOUNTS:
                        return account
            except Exception as e:
                print("Не удалось загрузить аккаунт:", e)
        return ACCOUNTS[0]

    def save_last_account(self):
        try:
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                f.write(self.account)
        except Exception as e:
            print("Не удалось сохранить аккаунт:", e)

    def load_data(self):
        save_file = self.get_save_file()
        if os.path.exists(save_file):
            try:
                with open(save_file, newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    codes = set()
                    for row in reader:
                        if row:
                            codes.add(row[0])
                    self.scanned_codes = codes
                    self.count = len(codes)
                    self.last_scan = max(codes) if codes else ''
            except Exception as e:
                print(f"Ошибка загрузки CSV для {self.account}:", e)
        else:
            self.scanned_codes = set()
            self.count = 0
            self.last_scan = ''

    def save_data(self):
        save_file = self.get_save_file()
        try:
            with open(save_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                for code in self.scanned_codes:
                    writer.writerow([code])
        except Exception as e:
            print(f"Ошибка сохранения CSV для {self.account}:", e)

    def start_listening(self):
        def on_press(key):
            try:
                if not self.running or self.paused:
                    return

                now = time.time()
                delay = now - self.last_key_time
                self.last_key_time = now

                if delay > self.max_delay:
                    self.buffer = ''

                if hasattr(key, 'char') and key.char and key.char.isdigit():
                    self.buffer += key.char
                elif key == pyn_keyboard.Key.enter:
                    if len(self.buffer) == 18 and self.buffer.isdigit():
                        if self.buffer not in self.scanned_codes:
                            self.scanned_codes.add(self.buffer)
                            self.count += 1
                            self.last_scan = self.buffer
                            self.save_data()
                    self.buffer = ''
            except Exception as e:
                print("Ошибка при обработке клавиши:", e)

        listener = pyn_keyboard.Listener(on_press=on_press)
        listener.start()

    def stop(self):
        self.running = False

    def update_tooltip(self):
        if self.icon:
            tooltip = f"Skannerlar soni: {self.count} | Oxirgisi: {self.last_scan or '-'} | Account: {self.account}"
            self.icon.title = tooltip

    def toggle_pause(self):
        self.paused = not self.paused
        if self.icon:
            self.icon.icon = create_image(self.paused)

    def switch_account(self, icon, item=None, account_name=None):
        if account_name is None:
            return
        self.account = account_name
        self.save_last_account()
        self.load_data()
        self.update_tooltip()
        if self.icon:
            self.icon.icon = create_image(self.paused)

def create_image(paused):
    color = (128, 128, 0) if paused else (0, 128, 0)
    image = Image.new('RGB', (64, 64), color)
    draw = ImageDraw.Draw(image)
    draw.rectangle((16, 16, 48, 48), fill='white')
    return image

def show_message(title, msg, icon=None):
    ctypes.windll.user32.MessageBoxW(0, msg, title, 0)

def show_money(icon, item, scanner):
    total = scanner.count * 90
    show_message("Man nech pul topdim?", f"Hozirgi pulingiz: {total}")

def create_menu(scanner: ScannerApp):
    account_items = [
        pystray.MenuItem(
            account,
            partial(scanner.switch_account, account_name=account),
            checked=lambda item, acc=account: scanner.account == acc,
            radio=True
        )
        for account in ACCOUNTS
    ]
    return pystray.Menu(
        pystray.MenuItem('Аккаунт', pystray.Menu(*account_items)),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem(
            "Davom ettirish" if scanner.paused else "Pauza",
            lambda icon, item: scanner.toggle_pause()
        ),
        pystray.MenuItem(
            "Man nech pul topdim?",
            lambda icon, item: show_money(icon, item, scanner)
        ),
        pystray.MenuItem(
            "Chiqish",
            lambda icon, item: (scanner.stop(), scanner.icon.stop() if scanner.icon else None)
        )
    )

def create_icon(scanner: ScannerApp):
    icon = pystray.Icon("scanner_tray")
    icon.icon = create_image(scanner.paused)
    icon.title = "Skanner"
    icon.menu = create_menu(scanner)
    scanner.icon = icon

    def update_loop():
        while scanner.running:
            scanner.update_tooltip()
            time.sleep(1)

    threading.Thread(target=update_loop, daemon=True).start()

    return icon

if __name__ == "__main__":
    scanner = ScannerApp()

    scanner.start_listening()

    icon = create_icon(scanner)
    icon.run()
